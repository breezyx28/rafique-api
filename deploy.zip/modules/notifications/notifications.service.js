"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationsService = exports.LOW_STOCK_THRESHOLD = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const notification_entity_1 = require("./entities/notification.entity");
const order_entity_1 = require("../orders/entities/order.entity");
const inventory_item_entity_1 = require("../inventory/entities/inventory-item.entity");
exports.LOW_STOCK_THRESHOLD = 6;
let NotificationsService = class NotificationsService {
    constructor(notificationRepo, orderRepo, inventoryRepo) {
        this.notificationRepo = notificationRepo;
        this.orderRepo = orderRepo;
        this.inventoryRepo = inventoryRepo;
    }
    async findAll(limit = 20) {
        const notifications = await this.notificationRepo.find({
            order: { createdAt: 'DESC' },
            take: limit,
        });
        return notifications;
    }
    async markRead(id) {
        await this.notificationRepo.update(id, { isRead: true });
    }
    async markAllRead() {
        await this.notificationRepo
            .createQueryBuilder()
            .update(notification_entity_1.Notification)
            .set({ isRead: true })
            .where('is_read = :isRead', { isRead: false })
            .execute();
    }
    async createStockNotificationIfNeeded(itemId) {
        const item = await this.inventoryRepo.findOne({
            where: { id: itemId },
            relations: ['product'],
        });
        if (!item)
            return;
        if (item.qty > exports.LOW_STOCK_THRESHOLD) {
            return;
        }
        const existing = await this.notificationRepo.findOne({
            where: {
                kind: 'stock',
                inventoryItemId: item.id,
                isRead: false,
            },
        });
        if (existing)
            return;
        const title = `Low stock: ${item.product?.name ?? 'Item'} (qty ${item.qty})`;
        const notification = this.notificationRepo.create({
            title,
            subtitle: 'Inventory alert',
            kind: 'stock',
            inventoryItemId: item.id,
            orderId: null,
            window: null,
            isRead: false,
        });
        await this.notificationRepo.save(notification);
    }
    async generateDueNotificationsForDate(date) {
        const isoDate = date.toISOString().slice(0, 10);
        const today = new Date(isoDate);
        const orders = await this.orderRepo
            .createQueryBuilder('o')
            .leftJoinAndSelect('o.customer', 'customer')
            .where('o.dueDate IS NOT NULL')
            .andWhere('o.status IN (:...statuses)', {
            statuses: ['pending', 'in_progress', 'ready'],
        })
            .getMany();
        for (const order of orders) {
            if (!order.dueDate)
                continue;
            const due = new Date(order.dueDate);
            const diffMs = due.getTime() - today.getTime();
            const daysUntilDue = Math.round(diffMs / (24 * 60 * 60 * 1000));
            let window = null;
            let suffix = null;
            if (daysUntilDue === 2) {
                window = 'due_in_2';
                suffix = 'due in 2 days';
            }
            else if (daysUntilDue === 1) {
                window = 'due_tomorrow';
                suffix = 'due tomorrow';
            }
            else if (daysUntilDue === 0) {
                window = 'due_today';
                suffix = 'due today';
            }
            if (!window || !suffix)
                continue;
            const existing = await this.notificationRepo.findOne({
                where: {
                    kind: 'due',
                    orderId: order.id,
                    window,
                },
            });
            if (existing)
                continue;
            const title = `Order #${order.orderNumber} ${suffix}`;
            const subtitle = order.customer
                ? `Customer: ${order.customer.name}`
                : null;
            const notification = this.notificationRepo.create({
                title,
                subtitle,
                kind: 'due',
                orderId: order.id,
                inventoryItemId: null,
                window,
                isRead: false,
            });
            await this.notificationRepo.save(notification);
        }
    }
};
exports.NotificationsService = NotificationsService;
exports.NotificationsService = NotificationsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(notification_entity_1.Notification)),
    __param(1, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __param(2, (0, typeorm_1.InjectRepository)(inventory_item_entity_1.InventoryItem)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], NotificationsService);
//# sourceMappingURL=notifications.service.js.map