import { Repository } from 'typeorm';
import { Notification } from './entities/notification.entity';
import { Order } from '../orders/entities/order.entity';
import { InventoryItem } from '../inventory/entities/inventory-item.entity';
export declare const LOW_STOCK_THRESHOLD = 6;
export declare class NotificationsService {
    private notificationRepo;
    private orderRepo;
    private inventoryRepo;
    constructor(notificationRepo: Repository<Notification>, orderRepo: Repository<Order>, inventoryRepo: Repository<InventoryItem>);
    findAll(limit?: number): Promise<Notification[]>;
    markRead(id: number): Promise<void>;
    markAllRead(): Promise<void>;
    createStockNotificationIfNeeded(itemId: number): Promise<void>;
    generateDueNotificationsForDate(date: Date): Promise<void>;
}
