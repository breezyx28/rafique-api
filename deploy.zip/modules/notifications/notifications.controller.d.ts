import { NotificationsService } from './notifications.service';
export declare class NotificationsController {
    private readonly notificationsService;
    constructor(notificationsService: NotificationsService);
    findAll(limit?: string): Promise<import("./entities/notification.entity").Notification[]>;
    markRead(id: string): Promise<{
        ok: boolean;
    }>;
    markAllRead(): Promise<{
        ok: boolean;
    }>;
}
