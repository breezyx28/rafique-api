export type NotificationKind = 'due' | 'stock';
export declare class Notification {
    id: number;
    title: string;
    subtitle: string | null;
    kind: NotificationKind;
    orderId: number | null;
    inventoryItemId: number | null;
    window: string | null;
    isRead: boolean;
    createdAt: Date;
}
