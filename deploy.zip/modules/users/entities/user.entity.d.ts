import { Role } from './role.entity';
export declare class User {
    id: number;
    username: string;
    passwordHash: string;
    roleId: number;
    role: Role;
    createdAt: Date;
}
