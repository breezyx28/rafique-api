import { Repository } from 'typeorm';
import { User } from './entities/user.entity';
export declare class UsersService {
    private userRepo;
    constructor(userRepo: Repository<User>);
    findByUsername(username: string): Promise<User | null>;
    findById(id: number): Promise<User | null>;
    updatePassword(userId: number, newPassword: string): Promise<void>;
    findAll(): Promise<User[]>;
}
