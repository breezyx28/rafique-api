export declare class UsersModule {
}
