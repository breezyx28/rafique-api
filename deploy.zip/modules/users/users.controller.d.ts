import { UsersService } from './users.service';
import { ChangePasswordDto } from './dto/change-password.dto';
export declare class UsersController {
    private readonly usersService;
    constructor(usersService: UsersService);
    changePassword(id: string, dto: ChangePasswordDto): Promise<{
        ok: boolean;
    }>;
}
