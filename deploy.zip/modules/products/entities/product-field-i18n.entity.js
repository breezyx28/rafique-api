"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductFieldI18n = void 0;
const typeorm_1 = require("typeorm");
const product_field_entity_1 = require("./product-field.entity");
let ProductFieldI18n = class ProductFieldI18n {
};
exports.ProductFieldI18n = ProductFieldI18n;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ProductFieldI18n.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'field_id' }),
    __metadata("design:type", Number)
], ProductFieldI18n.prototype, "fieldId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: ['en', 'ar', 'bn'] }),
    __metadata("design:type", String)
], ProductFieldI18n.prototype, "lang", void 0);
__decorate([
    (0, typeorm_1.Column)({ length: 255 }),
    __metadata("design:type", String)
], ProductFieldI18n.prototype, "label", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => product_field_entity_1.ProductField, (f) => f.i18n, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'field_id' }),
    __metadata("design:type", product_field_entity_1.ProductField)
], ProductFieldI18n.prototype, "field", void 0);
exports.ProductFieldI18n = ProductFieldI18n = __decorate([
    (0, typeorm_1.Entity)('product_field_i18n')
], ProductFieldI18n);
//# sourceMappingURL=product-field-i18n.entity.js.map