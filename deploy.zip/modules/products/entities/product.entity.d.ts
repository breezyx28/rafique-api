import { ProductField } from './product-field.entity';
import { OrderItem } from '../../orders/entities/order-item.entity';
import { InventoryItem } from '../../inventory/entities/inventory-item.entity';
export declare enum ProductType {
    CUSTOM = "custom",
    READY = "ready"
}
export declare class Product {
    id: number;
    name: string;
    type: ProductType;
    basePrice: number;
    createdAt: Date;
    fields: ProductField[];
    orderItems: OrderItem[];
    inventoryItems: InventoryItem[];
}
