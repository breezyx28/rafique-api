import { Product } from './product.entity';
import { ProductFieldI18n } from './product-field-i18n.entity';
import { OrderMeasurement } from '../../orders/entities/order-measurement.entity';
export declare class ProductField {
    id: number;
    productId: number;
    fieldKey: string;
    inputType: string;
    required: boolean;
    sortOrder: number;
    product: Product;
    i18n: ProductFieldI18n[];
    orderMeasurements: OrderMeasurement[];
}
