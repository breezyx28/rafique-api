"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductField = void 0;
const typeorm_1 = require("typeorm");
const product_entity_1 = require("./product.entity");
const product_field_i18n_entity_1 = require("./product-field-i18n.entity");
const order_measurement_entity_1 = require("../../orders/entities/order-measurement.entity");
let ProductField = class ProductField {
};
exports.ProductField = ProductField;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ProductField.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'product_id' }),
    __metadata("design:type", Number)
], ProductField.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'field_key', length: 100 }),
    __metadata("design:type", String)
], ProductField.prototype, "fieldKey", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'input_type', length: 20, default: 'text' }),
    __metadata("design:type", String)
], ProductField.prototype, "inputType", void 0);
__decorate([
    (0, typeorm_1.Column)({ default: false }),
    __metadata("design:type", Boolean)
], ProductField.prototype, "required", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'sort_order', default: 0 }),
    __metadata("design:type", Number)
], ProductField.prototype, "sortOrder", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => product_entity_1.Product, (p) => p.fields, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'product_id' }),
    __metadata("design:type", product_entity_1.Product)
], ProductField.prototype, "product", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => product_field_i18n_entity_1.ProductFieldI18n, (i18n) => i18n.field),
    __metadata("design:type", Array)
], ProductField.prototype, "i18n", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => order_measurement_entity_1.OrderMeasurement, (m) => m.field),
    __metadata("design:type", Array)
], ProductField.prototype, "orderMeasurements", void 0);
exports.ProductField = ProductField = __decorate([
    (0, typeorm_1.Entity)('product_fields')
], ProductField);
//# sourceMappingURL=product-field.entity.js.map