import { ProductField } from './product-field.entity';
export type LangCode = 'en' | 'ar' | 'bn';
export declare class ProductFieldI18n {
    id: number;
    fieldId: number;
    lang: LangCode;
    label: string;
    field: ProductField;
}
