import { ProductsService } from './products.service';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { CreateProductFieldDto } from './dto/create-product-field.dto';
import { ProductType } from './entities/product.entity';
export declare class ProductsController {
    private readonly productsService;
    constructor(productsService: ProductsService);
    findAll(type?: ProductType): Promise<import("./entities/product.entity").Product[]>;
    findOne(id: string): Promise<import("./entities/product.entity").Product>;
    create(dto: CreateProductDto): Promise<import("./entities/product.entity").Product>;
    update(id: string, dto: UpdateProductDto): Promise<import("./entities/product.entity").Product>;
    remove(id: string): Promise<{
        ok: boolean;
    }>;
    getFields(id: string): Promise<import("./entities/product-field.entity").ProductField[]>;
    addField(id: string, dto: CreateProductFieldDto): Promise<import("./entities/product-field.entity").ProductField | null>;
    updateField(fieldId: string, dto: Partial<CreateProductFieldDto>): Promise<import("./entities/product-field.entity").ProductField | null>;
    removeField(fieldId: string): Promise<{
        ok: boolean;
    }>;
}
