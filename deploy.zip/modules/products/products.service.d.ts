import { Repository } from 'typeorm';
import { Product, ProductType } from './entities/product.entity';
import { ProductField } from './entities/product-field.entity';
import { ProductFieldI18n } from './entities/product-field-i18n.entity';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { CreateProductFieldDto } from './dto/create-product-field.dto';
export declare class ProductsService {
    private productRepo;
    private fieldRepo;
    private i18nRepo;
    constructor(productRepo: Repository<Product>, fieldRepo: Repository<ProductField>, i18nRepo: Repository<ProductFieldI18n>);
    findAll(type?: ProductType): Promise<Product[]>;
    findOne(id: number): Promise<Product>;
    create(dto: CreateProductDto): Promise<Product>;
    update(id: number, dto: UpdateProductDto): Promise<Product>;
    remove(id: number): Promise<{
        ok: boolean;
    }>;
    getFields(productId: number): Promise<ProductField[]>;
    addField(productId: number, dto: CreateProductFieldDto): Promise<ProductField | null>;
    updateField(fieldId: number, dto: Partial<CreateProductFieldDto>): Promise<ProductField | null>;
    removeField(fieldId: number): Promise<{
        ok: boolean;
    }>;
}
