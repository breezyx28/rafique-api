export declare class ProductFieldLabelDto {
    lang?: 'en' | 'ar' | 'bn';
    language?: 'en' | 'ar' | 'bn';
    label: string;
}
export declare class CreateProductFieldDto {
    fieldKey: string;
    inputType: string;
    required?: boolean;
    labels?: {
        lang: 'en' | 'ar' | 'bn';
        label: string;
    }[];
}
