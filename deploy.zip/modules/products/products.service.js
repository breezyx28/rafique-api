"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const product_entity_1 = require("./entities/product.entity");
const product_field_entity_1 = require("./entities/product-field.entity");
const product_field_i18n_entity_1 = require("./entities/product-field-i18n.entity");
let ProductsService = class ProductsService {
    constructor(productRepo, fieldRepo, i18nRepo) {
        this.productRepo = productRepo;
        this.fieldRepo = fieldRepo;
        this.i18nRepo = i18nRepo;
    }
    async findAll(type) {
        const where = type ? { type } : {};
        return this.productRepo.find({
            where,
            relations: ['fields', 'fields.i18n'],
            order: { id: 'ASC' },
        });
    }
    async findOne(id) {
        const product = await this.productRepo.findOne({
            where: { id },
            relations: ['fields', 'fields.i18n'],
        });
        if (!product)
            throw new common_1.NotFoundException('Product not found');
        return product;
    }
    async create(dto) {
        const product = this.productRepo.create(dto);
        return this.productRepo.save(product);
    }
    async update(id, dto) {
        await this.productRepo.update(id, dto);
        return this.findOne(id);
    }
    async remove(id) {
        const product = await this.findOne(id);
        await this.productRepo.remove(product);
        return { ok: true };
    }
    async getFields(productId) {
        await this.findOne(productId);
        return this.fieldRepo.find({
            where: { productId },
            relations: ['i18n'],
            order: { sortOrder: 'ASC', id: 'ASC' },
        });
    }
    async addField(productId, dto) {
        await this.findOne(productId);
        const maxOrder = await this.fieldRepo
            .createQueryBuilder('f')
            .select('MAX(f.sortOrder)', 'max')
            .where('f.productId = :id', { id: productId })
            .getRawOne();
        const field = this.fieldRepo.create({
            productId,
            fieldKey: dto.fieldKey,
            inputType: dto.inputType ?? 'text',
            required: dto.required ?? false,
            sortOrder: (maxOrder?.max ?? 0) + 1,
        });
        const saved = await this.fieldRepo.save(field);
        if (dto.labels?.length) {
            for (const label of dto.labels) {
                const lang = label.lang ?? label.language;
                if (lang) {
                    const i18n = this.i18nRepo.create({ fieldId: saved.id, lang, label: label.label });
                    await this.i18nRepo.save(i18n);
                }
            }
        }
        return this.fieldRepo.findOne({
            where: { id: saved.id },
            relations: ['i18n'],
        });
    }
    async updateField(fieldId, dto) {
        const field = await this.fieldRepo.findOne({ where: { id: fieldId } });
        if (!field)
            throw new common_1.NotFoundException('Field not found');
        if (dto.fieldKey != null)
            field.fieldKey = dto.fieldKey;
        if (dto.inputType != null)
            field.inputType = dto.inputType;
        if (dto.required != null)
            field.required = dto.required;
        await this.fieldRepo.save(field);
        if (dto.labels?.length) {
            await this.i18nRepo.delete({ fieldId });
            for (const label of dto.labels) {
                const lang = label.lang ?? label.language;
                if (lang) {
                    const i18n = this.i18nRepo.create({ fieldId, lang, label: label.label });
                    await this.i18nRepo.save(i18n);
                }
            }
        }
        return this.fieldRepo.findOne({
            where: { id: fieldId },
            relations: ['i18n'],
        });
    }
    async removeField(fieldId) {
        const field = await this.fieldRepo.findOne({ where: { id: fieldId } });
        if (!field)
            throw new common_1.NotFoundException('Field not found');
        await this.fieldRepo.remove(field);
        return { ok: true };
    }
};
exports.ProductsService = ProductsService;
exports.ProductsService = ProductsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(product_entity_1.Product)),
    __param(1, (0, typeorm_1.InjectRepository)(product_field_entity_1.ProductField)),
    __param(2, (0, typeorm_1.InjectRepository)(product_field_i18n_entity_1.ProductFieldI18n)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], ProductsService);
//# sourceMappingURL=products.service.js.map