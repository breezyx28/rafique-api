import { DashboardService } from './dashboard.service';
export declare class DashboardController {
    private readonly dashboardService;
    constructor(dashboardService: DashboardService);
    getStats(): Promise<{
        totalOrders: number;
        totalRevenue: number;
        activeCustomers: number;
        workingDays: number;
    }>;
    getSalesChart(year?: string, compareYear?: string): Promise<{
        year: number;
        compareYear: number | null;
        data: {
            month: number;
            total: number;
            compare: number | null;
        }[];
    }>;
    getTopProducts(limit?: string): Promise<{
        productId: any;
        name: any;
        qty: number;
        total: number;
    }[]>;
    getTopCustomers(limit?: string): Promise<{
        customerId: any;
        name: any;
        phone: any;
        ordersCount: number;
        totalSpent: number;
    }[]>;
}
