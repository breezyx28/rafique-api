"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DashboardService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const order_entity_1 = require("../orders/entities/order.entity");
const customer_entity_1 = require("../customers/entities/customer.entity");
let DashboardService = class DashboardService {
    constructor(orderRepo, customerRepo) {
        this.orderRepo = orderRepo;
        this.customerRepo = customerRepo;
    }
    async getStats() {
        const [totalOrders, revenueResult, activeCustomers, workingDays] = await Promise.all([
            this.orderRepo.count(),
            this.orderRepo.createQueryBuilder('o').select('SUM(o.total)', 'sum').getRawOne(),
            this.customerRepo.createQueryBuilder('c').innerJoin('c.orders', 'o').select('COUNT(DISTINCT c.id)', 'count').getRawOne(),
            Promise.resolve(22),
        ]);
        const totalRevenue = parseFloat(revenueResult?.sum ?? '0');
        const activeCount = parseInt(activeCustomers?.count ?? '0', 10);
        return {
            totalOrders,
            totalRevenue,
            activeCustomers: activeCount,
            workingDays,
        };
    }
    async getSalesChart(year, compareYear) {
        const months = await this.orderRepo
            .createQueryBuilder('o')
            .select('MONTH(o.created_at)', 'month')
            .addSelect('SUM(o.total)', 'total')
            .where('YEAR(o.created_at) = :year', { year })
            .groupBy('month')
            .getRawMany();
        const byMonth = {};
        for (let m = 1; m <= 12; m++)
            byMonth[m] = 0;
        for (const row of months)
            byMonth[row.month] = parseFloat(row.total ?? '0');
        let compare;
        if (compareYear) {
            const compareMonths = await this.orderRepo
                .createQueryBuilder('o')
                .select('MONTH(o.created_at)', 'month')
                .addSelect('SUM(o.total)', 'total')
                .where('YEAR(o.created_at) = :year', { year: compareYear })
                .groupBy('month')
                .getRawMany();
            compare = {};
            for (let m = 1; m <= 12; m++)
                compare[m] = 0;
            for (const row of compareMonths)
                compare[row.month] = parseFloat(row.total ?? '0');
        }
        return {
            year,
            compareYear: compareYear ?? null,
            data: Object.entries(byMonth).map(([m, total]) => ({
                month: parseInt(m, 10),
                total,
                compare: compare?.[parseInt(m, 10)] ?? null,
            })),
        };
    }
    async getTopProducts(limit = 10) {
        const result = await this.orderRepo
            .createQueryBuilder('o')
            .innerJoin('o.items', 'i')
            .innerJoin('i.product', 'p')
            .select('p.id', 'productId')
            .addSelect('p.name', 'name')
            .addSelect('SUM(i.qty)', 'qty')
            .addSelect('SUM(i.subtotal)', 'total')
            .groupBy('p.id')
            .addGroupBy('p.name')
            .orderBy('SUM(i.subtotal)', 'DESC')
            .limit(limit)
            .getRawMany();
        return result.map((r) => ({
            productId: r.productId,
            name: r.name,
            qty: parseInt(r.qty ?? '0', 10),
            total: parseFloat(r.total ?? '0'),
        }));
    }
    async getTopCustomers(limit = 20) {
        const result = await this.customerRepo
            .createQueryBuilder('c')
            .leftJoin('c.orders', 'o')
            .select('c.id', 'customerId')
            .addSelect('c.name', 'name')
            .addSelect('c.phone', 'phone')
            .addSelect('COUNT(o.id)', 'ordersCount')
            .addSelect('COALESCE(SUM(o.total), 0)', 'totalSpent')
            .groupBy('c.id')
            .addGroupBy('c.name')
            .addGroupBy('c.phone')
            .orderBy('totalSpent', 'DESC')
            .limit(limit)
            .getRawMany();
        return result.map((r) => ({
            customerId: r.customerId,
            name: r.name,
            phone: r.phone,
            ordersCount: parseInt(r.ordersCount ?? '0', 10),
            totalSpent: parseFloat(r.totalSpent ?? '0'),
        }));
    }
};
exports.DashboardService = DashboardService;
exports.DashboardService = DashboardService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __param(1, (0, typeorm_1.InjectRepository)(customer_entity_1.Customer)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], DashboardService);
//# sourceMappingURL=dashboard.service.js.map