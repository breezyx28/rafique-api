import { Repository } from 'typeorm';
import { Order } from '../orders/entities/order.entity';
import { Customer } from '../customers/entities/customer.entity';
export declare class DashboardService {
    private orderRepo;
    private customerRepo;
    constructor(orderRepo: Repository<Order>, customerRepo: Repository<Customer>);
    getStats(): Promise<{
        totalOrders: number;
        totalRevenue: number;
        activeCustomers: number;
        workingDays: number;
    }>;
    getSalesChart(year: number, compareYear?: number): Promise<{
        year: number;
        compareYear: number | null;
        data: {
            month: number;
            total: number;
            compare: number | null;
        }[];
    }>;
    getTopProducts(limit?: number): Promise<{
        productId: any;
        name: any;
        qty: number;
        total: number;
    }[]>;
    getTopCustomers(limit?: number): Promise<{
        customerId: any;
        name: any;
        phone: any;
        ordersCount: number;
        totalSpent: number;
    }[]>;
}
