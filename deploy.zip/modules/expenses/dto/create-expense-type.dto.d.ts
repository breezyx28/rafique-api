export declare class CreateExpenseTypeDto {
    name: string;
    isCustom?: boolean;
}
