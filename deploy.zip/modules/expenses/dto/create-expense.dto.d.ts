export declare class CreateExpenseDto {
    typeId: number;
    amount: number;
    date: string;
    note?: string;
}
