import { ExpensesService } from './expenses.service';
import { CreateExpenseDto } from './dto/create-expense.dto';
import { CreateExpenseTypeDto } from './dto/create-expense-type.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
export declare class ExpensesController {
    private readonly expensesService;
    constructor(expensesService: ExpensesService);
    getTypes(): Promise<import("./entities/expense-type.entity").ExpenseType[]>;
    createType(dto: CreateExpenseTypeDto): Promise<import("./entities/expense-type.entity").ExpenseType>;
    findAll(pagination: PaginationDto, from?: string, to?: string, typeId?: string): Promise<{
        data: import("./entities/expense.entity").Expense[];
        meta: {
            page: number;
            limit: number;
            total: number;
        };
    }>;
    summary(period?: 'today' | 'month' | 'year'): Promise<{
        total: any;
    }>;
    create(dto: CreateExpenseDto): Promise<import("./entities/expense.entity").Expense>;
    findOne(id: string): Promise<import("./entities/expense.entity").Expense>;
    update(id: string, dto: Partial<CreateExpenseDto>): Promise<import("./entities/expense.entity").Expense>;
    remove(id: string): Promise<{
        ok: boolean;
    }>;
}
