"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExpensesService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const expense_entity_1 = require("./entities/expense.entity");
const expense_type_entity_1 = require("./entities/expense-type.entity");
let ExpensesService = class ExpensesService {
    constructor(expenseRepo, typeRepo) {
        this.expenseRepo = expenseRepo;
        this.typeRepo = typeRepo;
    }
    async getTypes() {
        return this.typeRepo.find({ order: { name: 'ASC' } });
    }
    async createType(dto) {
        const type = this.typeRepo.create({ ...dto, isCustom: dto.isCustom ?? true });
        return this.typeRepo.save(type);
    }
    async findAll(pagination, from, to, typeId) {
        const { page = 1, limit = 20 } = pagination;
        const qb = this.expenseRepo
            .createQueryBuilder('e')
            .leftJoinAndSelect('e.type', 'type');
        if (from)
            qb.andWhere('e.date >= :from', { from });
        if (to)
            qb.andWhere('e.date <= :to', { to });
        if (typeId)
            qb.andWhere('e.typeId = :typeId', { typeId });
        const [items, total] = await qb
            .orderBy('e.date', 'DESC')
            .addOrderBy('e.id', 'DESC')
            .skip((page - 1) * limit)
            .take(limit)
            .getManyAndCount();
        return { data: items, meta: { page, limit, total } };
    }
    async create(dto) {
        const expense = this.expenseRepo.create(dto);
        return this.expenseRepo.save(expense);
    }
    async findOne(id) {
        const expense = await this.expenseRepo.findOne({
            where: { id },
            relations: ['type'],
        });
        if (!expense)
            throw new common_1.NotFoundException('Expense not found');
        return expense;
    }
    async update(id, dto) {
        await this.expenseRepo.update(id, dto);
        return this.findOne(id);
    }
    async remove(id) {
        const expense = await this.findOne(id);
        await this.expenseRepo.remove(expense);
        return { ok: true };
    }
    async getSummary(period) {
        const qb = this.expenseRepo.createQueryBuilder('e').select('SUM(e.amount)', 'total');
        const now = new Date();
        if (period === 'today') {
            qb.andWhere('e.date = :date', { date: now.toISOString().slice(0, 10) });
        }
        else if (period === 'month') {
            const start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
            qb.andWhere('e.date >= :start', { start });
        }
        else {
            const start = `${now.getFullYear()}-01-01`;
            qb.andWhere('e.date >= :start', { start });
        }
        const { total } = await qb.getRawOne();
        return { total: total ?? 0 };
    }
};
exports.ExpensesService = ExpensesService;
exports.ExpensesService = ExpensesService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(expense_entity_1.Expense)),
    __param(1, (0, typeorm_1.InjectRepository)(expense_type_entity_1.ExpenseType)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], ExpensesService);
//# sourceMappingURL=expenses.service.js.map