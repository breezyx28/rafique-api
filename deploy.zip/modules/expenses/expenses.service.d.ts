import { Repository } from 'typeorm';
import { Expense } from './entities/expense.entity';
import { ExpenseType } from './entities/expense-type.entity';
import { CreateExpenseDto } from './dto/create-expense.dto';
import { CreateExpenseTypeDto } from './dto/create-expense-type.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
export declare class ExpensesService {
    private expenseRepo;
    private typeRepo;
    constructor(expenseRepo: Repository<Expense>, typeRepo: Repository<ExpenseType>);
    getTypes(): Promise<ExpenseType[]>;
    createType(dto: CreateExpenseTypeDto): Promise<ExpenseType>;
    findAll(pagination: PaginationDto, from?: string, to?: string, typeId?: number): Promise<{
        data: Expense[];
        meta: {
            page: number;
            limit: number;
            total: number;
        };
    }>;
    create(dto: CreateExpenseDto): Promise<Expense>;
    findOne(id: number): Promise<Expense>;
    update(id: number, dto: Partial<CreateExpenseDto>): Promise<Expense>;
    remove(id: number): Promise<{
        ok: boolean;
    }>;
    getSummary(period: 'today' | 'month' | 'year'): Promise<{
        total: any;
    }>;
}
