import type { Expense } from './expense.entity';
export declare class ExpenseType {
    id: number;
    name: string;
    isCustom: boolean;
    expenses: Expense[];
}
