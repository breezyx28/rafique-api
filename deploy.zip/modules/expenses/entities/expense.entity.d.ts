import { ExpenseType } from './expense-type.entity';
export declare class Expense {
    id: number;
    typeId: number;
    amount: number;
    date: string;
    note: string | null;
    createdAt: Date;
    type: ExpenseType;
}
