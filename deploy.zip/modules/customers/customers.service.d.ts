import { Repository } from 'typeorm';
import { Customer } from './entities/customer.entity';
import { CreateCustomerDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
export declare class CustomersService {
    private repo;
    constructor(repo: Repository<Customer>);
    create(dto: CreateCustomerDto): Promise<Customer>;
    findAllSimple(): Promise<Customer[]>;
    findAll(pagination: PaginationDto, search?: string, phone?: string): Promise<{
        data: {
            ordersCount: number;
            totalSpent: number;
            lastOrderDate: string | null;
            id: number;
            name: string;
            phone: string;
            notes: string | null;
            createdAt: Date;
            orders: import("../orders/entities/order.entity").Order[];
        }[];
        meta: {
            page: number;
            limit: number;
            total: number;
        };
    }>;
    findByPhone(phone: string): Promise<Customer | null>;
    findOne(id: number): Promise<{
        ordersCount: number;
        totalSpent: number;
        lastOrderDate: string | null;
        id: number;
        name: string;
        phone: string;
        notes: string | null;
        createdAt: Date;
        orders: import("../orders/entities/order.entity").Order[];
    }>;
    update(id: number, dto: UpdateCustomerDto): Promise<{
        ordersCount: number;
        totalSpent: number;
        lastOrderDate: string | null;
        id: number;
        name: string;
        phone: string;
        notes: string | null;
        createdAt: Date;
        orders: import("../orders/entities/order.entity").Order[];
    }>;
    remove(id: number): Promise<{
        ok: boolean;
    }>;
}
