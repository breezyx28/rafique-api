"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomersService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const customer_entity_1 = require("./entities/customer.entity");
let CustomersService = class CustomersService {
    constructor(repo) {
        this.repo = repo;
    }
    async create(dto) {
        const customer = this.repo.create(dto);
        return this.repo.save(customer);
    }
    async findAllSimple() {
        return this.repo.find({
            select: ['id', 'name', 'phone'],
            order: { name: 'ASC', id: 'ASC' },
        });
    }
    async findAll(pagination, search, phone) {
        const { page = 1, limit = 20 } = pagination;
        const qb = this.repo.createQueryBuilder('c');
        if (search) {
            qb.andWhere('(c.name LIKE :search OR c.phone LIKE :search)', {
                search: `%${search}%`,
            });
        }
        if (phone) {
            qb.andWhere('c.phone = :phone', { phone });
        }
        const [items, total] = await qb
            .orderBy('c.id', 'DESC')
            .skip((page - 1) * limit)
            .take(limit)
            .getManyAndCount();
        if (!items.length) {
            return { data: [], meta: { page, limit, total } };
        }
        const ids = items.map((c) => c.id);
        const aggregates = await this.repo
            .createQueryBuilder('c')
            .leftJoin('c.orders', 'o')
            .select('c.id', 'id')
            .addSelect('COUNT(o.id)', 'ordersCount')
            .addSelect('COALESCE(SUM(o.total), 0)', 'totalSpent')
            .addSelect('MAX(o.created_at)', 'lastOrderDate')
            .where('c.id IN (:...ids)', { ids })
            .groupBy('c.id')
            .getRawMany();
        const map = new Map();
        for (const row of aggregates) {
            const id = Number(row.id);
            const ordersCount = Number(row.ordersCount ?? 0);
            const totalSpent = Number(row.totalSpent ?? 0);
            const lastOrderDate = row.lastOrderDate != null ? String(row.lastOrderDate) : null;
            map.set(id, { ordersCount, totalSpent, lastOrderDate });
        }
        const enriched = items.map((c) => {
            const agg = map.get(c.id);
            return {
                ...c,
                ordersCount: agg?.ordersCount ?? 0,
                totalSpent: agg?.totalSpent ?? 0,
                lastOrderDate: agg?.lastOrderDate ?? null,
            };
        });
        return { data: enriched, meta: { page, limit, total } };
    }
    async findByPhone(phone) {
        return this.repo.findOne({ where: { phone } });
    }
    async findOne(id) {
        const customer = await this.repo.findOne({
            where: { id },
            relations: ['orders'],
        });
        if (!customer)
            throw new common_1.NotFoundException('Customer not found');
        const orders = customer.orders ?? [];
        const ordersCount = orders.length;
        const totalSpent = orders.reduce((sum, o) => sum + Number(o.total ?? 0), 0);
        const lastOrderDate = orders.length > 0
            ? orders
                .map((o) => o.createdAt)
                .filter((d) => !!d)
                .sort((a, b) => b.getTime() - a.getTime())[0]
                ?.toISOString()
                .slice(0, 10) ?? null
            : null;
        return {
            ...customer,
            ordersCount,
            totalSpent,
            lastOrderDate,
        };
    }
    async update(id, dto) {
        await this.repo.update(id, dto);
        return this.findOne(id);
    }
    async remove(id) {
        const customer = await this.findOne(id);
        await this.repo.remove(customer);
        return { ok: true };
    }
};
exports.CustomersService = CustomersService;
exports.CustomersService = CustomersService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(customer_entity_1.Customer)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], CustomersService);
//# sourceMappingURL=customers.service.js.map