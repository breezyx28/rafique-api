import { Order } from '../../orders/entities/order.entity';
export declare class Customer {
    id: number;
    name: string;
    phone: string;
    notes: string | null;
    createdAt: Date;
    orders: Order[];
}
