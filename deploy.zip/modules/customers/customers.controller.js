"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomersController = void 0;
const common_1 = require("@nestjs/common");
const customers_service_1 = require("./customers.service");
const create_customer_dto_1 = require("./dto/create-customer.dto");
const update_customer_dto_1 = require("./dto/update-customer.dto");
const jwt_auth_guard_1 = require("../../common/guards/jwt-auth.guard");
const orders_service_1 = require("../orders/orders.service");
const pagination_dto_1 = require("../../common/dto/pagination.dto");
let CustomersController = class CustomersController {
    constructor(customersService, ordersService) {
        this.customersService = customersService;
        this.ordersService = ordersService;
    }
    async findAll(pagination, search, phone) {
        return this.customersService.findAll(pagination, search, phone);
    }
    async listSimple() {
        return this.customersService.findAllSimple();
    }
    async create(dto) {
        return this.customersService.create(dto);
    }
    async findOne(id) {
        return this.customersService.findOne(parseInt(id, 10));
    }
    async getMeasurements(id) {
        const orders = await this.ordersService.findByCustomerWithMeasurements(parseInt(id, 10));
        return orders.map((order) => ({
            id: order.id,
            createdAt: order.createdAt,
            items: order.items.map((item) => ({
                productName: item.product?.name ?? null,
                measurements: item.measurements.map((m) => ({
                    id: m.id,
                    fieldId: m.fieldId,
                    value: m.value,
                    field: m.field
                        ? {
                            id: m.field.id,
                            fieldKey: m.field.fieldKey,
                            inputType: m.field.inputType,
                            required: m.field.required,
                            i18n: m.field.i18n,
                        }
                        : null,
                })),
            })),
        }));
    }
    async update(id, dto) {
        return this.customersService.update(parseInt(id, 10), dto);
    }
    async remove(id) {
        return this.customersService.remove(parseInt(id, 10));
    }
};
exports.CustomersController = CustomersController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, common_1.Query)('search')),
    __param(2, (0, common_1.Query)('phone')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [pagination_dto_1.PaginationDto, String, String]),
    __metadata("design:returntype", Promise)
], CustomersController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('list'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], CustomersController.prototype, "listSimple", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_customer_dto_1.CreateCustomerDto]),
    __metadata("design:returntype", Promise)
], CustomersController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], CustomersController.prototype, "findOne", null);
__decorate([
    (0, common_1.Get)(':id/measurements'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], CustomersController.prototype, "getMeasurements", null);
__decorate([
    (0, common_1.Patch)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_customer_dto_1.UpdateCustomerDto]),
    __metadata("design:returntype", Promise)
], CustomersController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], CustomersController.prototype, "remove", null);
exports.CustomersController = CustomersController = __decorate([
    (0, common_1.Controller)('customers'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:paramtypes", [customers_service_1.CustomersService,
        orders_service_1.OrdersService])
], CustomersController);
//# sourceMappingURL=customers.controller.js.map