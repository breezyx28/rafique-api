import { CustomersService } from './customers.service';
import { CreateCustomerDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';
import { OrdersService } from '../orders/orders.service';
import { PaginationDto } from '../../common/dto/pagination.dto';
export declare class CustomersController {
    private readonly customersService;
    private readonly ordersService;
    constructor(customersService: CustomersService, ordersService: OrdersService);
    findAll(pagination: PaginationDto, search?: string, phone?: string): Promise<{
        data: {
            ordersCount: number;
            totalSpent: number;
            lastOrderDate: string | null;
            id: number;
            name: string;
            phone: string;
            notes: string | null;
            createdAt: Date;
            orders: import("../orders/entities/order.entity").Order[];
        }[];
        meta: {
            page: number;
            limit: number;
            total: number;
        };
    }>;
    listSimple(): Promise<import("./entities/customer.entity").Customer[]>;
    create(dto: CreateCustomerDto): Promise<import("./entities/customer.entity").Customer>;
    findOne(id: string): Promise<{
        ordersCount: number;
        totalSpent: number;
        lastOrderDate: string | null;
        id: number;
        name: string;
        phone: string;
        notes: string | null;
        createdAt: Date;
        orders: import("../orders/entities/order.entity").Order[];
    }>;
    getMeasurements(id: string): Promise<{
        id: number;
        createdAt: Date;
        items: {
            productName: string;
            measurements: {
                id: number;
                fieldId: number;
                value: string;
                field: {
                    id: number;
                    fieldKey: string;
                    inputType: string;
                    required: boolean;
                    i18n: import("../products/entities/product-field-i18n.entity").ProductFieldI18n[];
                } | null;
            }[];
        }[];
    }[]>;
    update(id: string, dto: UpdateCustomerDto): Promise<{
        ordersCount: number;
        totalSpent: number;
        lastOrderDate: string | null;
        id: number;
        name: string;
        phone: string;
        notes: string | null;
        createdAt: Date;
        orders: import("../orders/entities/order.entity").Order[];
    }>;
    remove(id: string): Promise<{
        ok: boolean;
    }>;
}
