import { Repository } from 'typeorm';
import { AppSetting } from './entities/app-setting.entity';
export declare class SettingsService {
    private repo;
    constructor(repo: Repository<AppSetting>);
    get(key?: string): Promise<unknown>;
    set(key: string, value: Record<string, unknown> | string | number | boolean): Promise<unknown>;
    patch(updates: Record<string, unknown>): Promise<unknown>;
}
