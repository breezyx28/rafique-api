export declare class AppSetting {
    key: string;
    value: unknown;
}
