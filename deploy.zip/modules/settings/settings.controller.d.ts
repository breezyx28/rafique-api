import { SettingsService } from './settings.service';
export declare class SettingsController {
    private readonly settingsService;
    constructor(settingsService: SettingsService);
    get(): Promise<unknown>;
    patch(body: Record<string, unknown>): Promise<unknown>;
}
