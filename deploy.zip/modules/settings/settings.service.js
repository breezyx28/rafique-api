"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SettingsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const app_setting_entity_1 = require("./entities/app-setting.entity");
const DEFAULT_SETTINGS = {
    workshopName: '',
    workshopPhone: '',
    workshopAddress: '',
    logoUrl: '',
    language: 'en',
    currency: 'SDG',
    dateFormat: 'YYYY-MM-DD',
    printer: '',
    showOrderSubmitConfirm: true,
    adminName: '',
    adminUsername: '',
};
let SettingsService = class SettingsService {
    constructor(repo) {
        this.repo = repo;
    }
    async get(key) {
        if (key) {
            const row = await this.repo.findOne({ where: { key } });
            if (row)
                return row.value;
            if (key in DEFAULT_SETTINGS) {
                return DEFAULT_SETTINGS[key];
            }
            return null;
        }
        const rows = await this.repo.find();
        const current = rows.reduce((acc, r) => ({ ...acc, [r.key]: r.value }), {});
        for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) {
            if (!(k in current)) {
                current[k] = v;
            }
        }
        return current;
    }
    async set(key, value) {
        const existing = await this.repo.findOne({ where: { key } });
        const entity = Object.assign(existing ?? new app_setting_entity_1.AppSetting(), { key, value });
        await this.repo.save(entity);
        return this.get(key);
    }
    async patch(updates) {
        for (const [key, value] of Object.entries(updates)) {
            await this.set(key, value);
        }
        return this.get();
    }
};
exports.SettingsService = SettingsService;
exports.SettingsService = SettingsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(app_setting_entity_1.AppSetting)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], SettingsService);
//# sourceMappingURL=settings.service.js.map