export declare class CreateInventoryItemDto {
    productId: number;
    size?: string;
    qty: number;
    price: number;
}
