export declare class CreateFabricDto {
    name: string;
    unit?: string;
    qty: number;
    costPerUnit: number;
}
