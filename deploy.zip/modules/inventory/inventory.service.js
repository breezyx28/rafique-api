"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventoryService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const inventory_item_entity_1 = require("./entities/inventory-item.entity");
const fabric_entity_1 = require("./entities/fabric.entity");
const notifications_service_1 = require("../notifications/notifications.service");
let InventoryService = class InventoryService {
    constructor(itemRepo, fabricRepo, notificationsService) {
        this.itemRepo = itemRepo;
        this.fabricRepo = fabricRepo;
        this.notificationsService = notificationsService;
    }
    async findAllItems(pagination) {
        const { page = 1, limit = 50 } = pagination;
        const [items, total] = await this.itemRepo.findAndCount({
            relations: ['product'],
            order: { id: 'DESC' },
            skip: (page - 1) * limit,
            take: limit,
        });
        return { data: items, meta: { page, limit, total } };
    }
    async createItem(dto) {
        const item = this.itemRepo.create(dto);
        const saved = await this.itemRepo.save(item);
        await this.notificationsService.createStockNotificationIfNeeded(saved.id);
        return saved;
    }
    async updateItem(id, dto) {
        await this.itemRepo.update(id, dto);
        const item = await this.itemRepo.findOne({ where: { id }, relations: ['product'] });
        if (!item)
            throw new common_1.NotFoundException('Inventory item not found');
        await this.notificationsService.createStockNotificationIfNeeded(item.id);
        return item;
    }
    async removeItem(id) {
        const item = await this.itemRepo.findOne({ where: { id } });
        if (!item)
            throw new common_1.NotFoundException('Inventory item not found');
        await this.itemRepo.remove(item);
        return { ok: true };
    }
    async findAllFabrics(pagination) {
        const { page = 1, limit = 50 } = pagination;
        const [items, total] = await this.fabricRepo.findAndCount({
            order: { id: 'DESC' },
            skip: (page - 1) * limit,
            take: limit,
        });
        return { data: items, meta: { page, limit, total } };
    }
    async createFabric(dto) {
        const fabric = this.fabricRepo.create(dto);
        return this.fabricRepo.save(fabric);
    }
    async updateFabric(id, dto) {
        await this.fabricRepo.update(id, dto);
        const fabric = await this.fabricRepo.findOne({ where: { id } });
        if (!fabric)
            throw new common_1.NotFoundException('Fabric not found');
        return fabric;
    }
    async removeFabric(id) {
        const fabric = await this.fabricRepo.findOne({ where: { id } });
        if (!fabric)
            throw new common_1.NotFoundException('Fabric not found');
        await this.fabricRepo.remove(fabric);
        return { ok: true };
    }
};
exports.InventoryService = InventoryService;
exports.InventoryService = InventoryService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(inventory_item_entity_1.InventoryItem)),
    __param(1, (0, typeorm_1.InjectRepository)(fabric_entity_1.Fabric)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        notifications_service_1.NotificationsService])
], InventoryService);
//# sourceMappingURL=inventory.service.js.map