import { InventoryService } from './inventory.service';
import { CreateInventoryItemDto } from './dto/create-inventory-item.dto';
import { CreateFabricDto } from './dto/create-fabric.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
export declare class InventoryController {
    private readonly inventoryService;
    constructor(inventoryService: InventoryService);
    findAllItems(pagination: PaginationDto): Promise<{
        data: import("./entities/inventory-item.entity").InventoryItem[];
        meta: {
            page: number;
            limit: number;
            total: number;
        };
    }>;
    createItem(dto: CreateInventoryItemDto): Promise<import("./entities/inventory-item.entity").InventoryItem>;
    updateItem(id: string, dto: Partial<CreateInventoryItemDto>): Promise<import("./entities/inventory-item.entity").InventoryItem>;
    removeItem(id: string): Promise<{
        ok: boolean;
    }>;
    findAllFabrics(pagination: PaginationDto): Promise<{
        data: import("./entities/fabric.entity").Fabric[];
        meta: {
            page: number;
            limit: number;
            total: number;
        };
    }>;
    createFabric(dto: CreateFabricDto): Promise<import("./entities/fabric.entity").Fabric>;
    updateFabric(id: string, dto: Partial<CreateFabricDto>): Promise<import("./entities/fabric.entity").Fabric>;
    removeFabric(id: string): Promise<{
        ok: boolean;
    }>;
}
