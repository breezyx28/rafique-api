import { Repository } from 'typeorm';
import { InventoryItem } from './entities/inventory-item.entity';
import { Fabric } from './entities/fabric.entity';
import { CreateInventoryItemDto } from './dto/create-inventory-item.dto';
import { CreateFabricDto } from './dto/create-fabric.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { NotificationsService } from '../notifications/notifications.service';
export declare class InventoryService {
    private itemRepo;
    private fabricRepo;
    private notificationsService;
    constructor(itemRepo: Repository<InventoryItem>, fabricRepo: Repository<Fabric>, notificationsService: NotificationsService);
    findAllItems(pagination: PaginationDto): Promise<{
        data: InventoryItem[];
        meta: {
            page: number;
            limit: number;
            total: number;
        };
    }>;
    createItem(dto: CreateInventoryItemDto): Promise<InventoryItem>;
    updateItem(id: number, dto: Partial<CreateInventoryItemDto>): Promise<InventoryItem>;
    removeItem(id: number): Promise<{
        ok: boolean;
    }>;
    findAllFabrics(pagination: PaginationDto): Promise<{
        data: Fabric[];
        meta: {
            page: number;
            limit: number;
            total: number;
        };
    }>;
    createFabric(dto: CreateFabricDto): Promise<Fabric>;
    updateFabric(id: number, dto: Partial<CreateFabricDto>): Promise<Fabric>;
    removeFabric(id: number): Promise<{
        ok: boolean;
    }>;
}
