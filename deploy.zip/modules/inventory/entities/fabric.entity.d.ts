export declare class Fabric {
    id: number;
    name: string;
    unit: string;
    qty: number;
    costPerUnit: number;
}
