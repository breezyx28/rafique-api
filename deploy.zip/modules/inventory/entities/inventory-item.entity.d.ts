import { Product } from '../../products/entities/product.entity';
export declare class InventoryItem {
    id: number;
    productId: number;
    size: string | null;
    qty: number;
    price: number;
    product: Product;
}
