"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Fabric = void 0;
const typeorm_1 = require("typeorm");
let Fabric = class Fabric {
};
exports.Fabric = Fabric;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], Fabric.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ length: 255 }),
    __metadata("design:type", String)
], Fabric.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ length: 50, default: 'meter' }),
    __metadata("design:type", String)
], Fabric.prototype, "unit", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 12, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], Fabric.prototype, "qty", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'cost_per_unit', type: 'decimal', precision: 12, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], Fabric.prototype, "costPerUnit", void 0);
exports.Fabric = Fabric = __decorate([
    (0, typeorm_1.Entity)('fabrics')
], Fabric);
//# sourceMappingURL=fabric.entity.js.map