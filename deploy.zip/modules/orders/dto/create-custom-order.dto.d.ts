import { PaymentMethod } from '../entities/order.entity';
export declare class OrderItemMeasurementDto {
    fieldId: number;
    value: string;
}
export declare class OrderItemDto {
    productId: number;
    qty: number;
    unitPrice: number;
    measurements: OrderItemMeasurementDto[];
}
export declare class CreateCustomOrderDto {
    customerId: number;
    items: OrderItemDto[];
    total: number;
    paid: number;
    paymentMethod?: PaymentMethod;
    dueDate?: string;
    noteCustomer?: string;
    noteWorkshop?: string;
}
