import { PaymentMethod } from '../entities/order.entity';
export declare class ReadyOrderItemDto {
    inventoryItemId: number;
    qty: number;
    unitPrice: number;
}
export declare class CreateReadyOrderDto {
    items: ReadyOrderItemDto[];
    total: number;
    paid: number;
    paymentMethod?: PaymentMethod;
    dueDate?: string;
}
