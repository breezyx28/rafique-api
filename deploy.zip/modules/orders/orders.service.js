"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const order_entity_1 = require("./entities/order.entity");
const order_item_entity_1 = require("./entities/order-item.entity");
const order_measurement_entity_1 = require("./entities/order-measurement.entity");
const inventory_item_entity_1 = require("../inventory/entities/inventory-item.entity");
const notifications_service_1 = require("../notifications/notifications.service");
let OrdersService = class OrdersService {
    constructor(orderRepo, itemRepo, measurementRepo, inventoryRepo, notificationsService) {
        this.orderRepo = orderRepo;
        this.itemRepo = itemRepo;
        this.measurementRepo = measurementRepo;
        this.inventoryRepo = inventoryRepo;
        this.notificationsService = notificationsService;
    }
    async nextOrderNumber() {
        const last = await this.orderRepo
            .createQueryBuilder('o')
            .select('o.orderNumber')
            .orderBy('o.id', 'DESC')
            .limit(1)
            .getOne();
        const num = last ? parseInt(last.orderNumber, 10) + 1 : 1;
        return num.toString().padStart(5, '0');
    }
    async createCustom(dto) {
        const orderNumber = await this.nextOrderNumber();
        const remaining = Number(dto.total) - Number(dto.paid);
        const order = this.orderRepo.create({
            orderNumber,
            customerId: dto.customerId,
            type: order_entity_1.OrderType.CUSTOM,
            status: order_entity_1.OrderStatus.PENDING,
            total: dto.total,
            paid: dto.paid,
            remaining,
            paymentMethod: dto.paymentMethod ?? null,
            dueDate: dto.dueDate ?? null,
            noteCustomer: dto.noteCustomer ?? null,
            noteWorkshop: dto.noteWorkshop ?? null,
        });
        const saved = await this.orderRepo.save(order);
        for (const it of dto.items) {
            const subtotal = Number(it.unitPrice) * it.qty;
            const item = this.itemRepo.create({
                orderId: saved.id,
                productId: it.productId,
                qty: it.qty,
                unitPrice: it.unitPrice,
                subtotal,
            });
            const savedItem = await this.itemRepo.save(item);
            for (const m of it.measurements) {
                const meas = this.measurementRepo.create({
                    orderItemId: savedItem.id,
                    fieldId: m.fieldId,
                    value: m.value,
                });
                await this.measurementRepo.save(meas);
            }
        }
        return this.findOne(saved.id);
    }
    async createReady(dto) {
        const orderNumber = await this.nextOrderNumber();
        const remaining = Number(dto.total) - Number(dto.paid);
        const order = this.orderRepo.create({
            orderNumber,
            customerId: null,
            type: order_entity_1.OrderType.READY,
            status: order_entity_1.OrderStatus.PENDING,
            total: dto.total,
            paid: dto.paid,
            remaining,
            paymentMethod: dto.paymentMethod ?? null,
            dueDate: dto.dueDate ?? null,
        });
        const saved = await this.orderRepo.save(order);
        for (const it of dto.items) {
            const inv = await this.inventoryRepo.findOne({ where: { id: it.inventoryItemId } });
            if (!inv)
                throw new common_1.NotFoundException(`Inventory item ${it.inventoryItemId} not found`);
            const subtotal = Number(it.unitPrice) * it.qty;
            await this.itemRepo.save(this.itemRepo.create({
                orderId: saved.id,
                productId: inv.productId,
                qty: it.qty,
                unitPrice: it.unitPrice,
                subtotal,
            }));
            inv.qty = Math.max(0, Number(inv.qty) - it.qty);
            await this.inventoryRepo.save(inv);
            await this.notificationsService.createStockNotificationIfNeeded(inv.id);
        }
        return this.findOne(saved.id);
    }
    async findAll(pagination, filters) {
        const { page = 1, limit = 20 } = pagination;
        const qb = this.orderRepo
            .createQueryBuilder('o')
            .leftJoinAndSelect('o.customer', 'customer')
            .leftJoinAndSelect('o.items', 'items')
            .leftJoinAndSelect('items.product', 'product');
        if (filters?.type)
            qb.andWhere('o.type = :type', { type: filters.type });
        if (filters?.status)
            qb.andWhere('o.status = :status', { status: filters.status });
        if (filters?.from)
            qb.andWhere('o.created_at >= :from', { from: filters.from });
        if (filters?.to)
            qb.andWhere('o.created_at <= :to', { to: filters.to });
        const [items, total] = await qb
            .orderBy('o.id', 'DESC')
            .skip((page - 1) * limit)
            .take(limit)
            .getManyAndCount();
        return { data: items, meta: { page, limit, total } };
    }
    async findOne(id) {
        const order = await this.orderRepo.findOne({
            where: { id },
            relations: ['customer', 'items', 'items.product', 'items.measurements', 'items.measurements.field', 'items.measurements.field.i18n'],
        });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        return order;
    }
    async findByCustomerWithMeasurements(customerId) {
        const orders = await this.orderRepo.find({
            where: { customer: { id: customerId } },
            relations: [
                'customer',
                'items',
                'items.product',
                'items.measurements',
                'items.measurements.field',
                'items.measurements.field.i18n',
            ],
            order: { id: 'DESC' },
        });
        return orders;
    }
    async update(id, updates) {
        await this.orderRepo.update(id, updates);
        return this.findOne(id);
    }
    async remove(id) {
        const order = await this.findOne(id);
        await this.orderRepo.remove(order);
        return { ok: true };
    }
};
exports.OrdersService = OrdersService;
exports.OrdersService = OrdersService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __param(1, (0, typeorm_1.InjectRepository)(order_item_entity_1.OrderItem)),
    __param(2, (0, typeorm_1.InjectRepository)(order_measurement_entity_1.OrderMeasurement)),
    __param(3, (0, typeorm_1.InjectRepository)(inventory_item_entity_1.InventoryItem)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        notifications_service_1.NotificationsService])
], OrdersService);
//# sourceMappingURL=orders.service.js.map