import { OrderItem } from './order-item.entity';
import type { ProductField } from '../../products/entities/product-field.entity';
export declare class OrderMeasurement {
    id: number;
    orderItemId: number;
    fieldId: number;
    value: string;
    orderItem: OrderItem;
    field: ProductField;
}
