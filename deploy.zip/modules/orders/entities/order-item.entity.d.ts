import { Order } from './order.entity';
import { Product } from '../../products/entities/product.entity';
import { OrderMeasurement } from './order-measurement.entity';
export declare class OrderItem {
    id: number;
    orderId: number;
    productId: number;
    qty: number;
    unitPrice: number;
    subtotal: number;
    order: Order;
    product: Product;
    measurements: OrderMeasurement[];
}
