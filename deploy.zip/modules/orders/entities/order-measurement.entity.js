"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderMeasurement = void 0;
const typeorm_1 = require("typeorm");
const order_item_entity_1 = require("./order-item.entity");
let OrderMeasurement = class OrderMeasurement {
};
exports.OrderMeasurement = OrderMeasurement;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], OrderMeasurement.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'order_item_id' }),
    __metadata("design:type", Number)
], OrderMeasurement.prototype, "orderItemId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'field_id' }),
    __metadata("design:type", Number)
], OrderMeasurement.prototype, "fieldId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text' }),
    __metadata("design:type", String)
], OrderMeasurement.prototype, "value", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => order_item_entity_1.OrderItem, (oi) => oi.measurements, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'order_item_id' }),
    __metadata("design:type", order_item_entity_1.OrderItem)
], OrderMeasurement.prototype, "orderItem", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)('ProductField'),
    (0, typeorm_1.JoinColumn)({ name: 'field_id' }),
    __metadata("design:type", Function)
], OrderMeasurement.prototype, "field", void 0);
exports.OrderMeasurement = OrderMeasurement = __decorate([
    (0, typeorm_1.Entity)('order_measurements')
], OrderMeasurement);
//# sourceMappingURL=order-measurement.entity.js.map