import { Customer } from '../../customers/entities/customer.entity';
import { OrderItem } from './order-item.entity';
export declare enum OrderType {
    CUSTOM = "custom",
    READY = "ready"
}
export declare enum OrderStatus {
    PENDING = "pending",
    IN_PROGRESS = "in_progress",
    READY = "ready",
    DELIVERED = "delivered",
    CANCELLED = "cancelled"
}
export declare enum PaymentMethod {
    CASH = "cash",
    MBOK = "mbok"
}
export declare class Order {
    id: number;
    orderNumber: string;
    customerId: number | null;
    type: OrderType;
    status: OrderStatus;
    total: number;
    paid: number;
    remaining: number;
    paymentMethod: PaymentMethod | null;
    dueDate: string | null;
    noteCustomer: string | null;
    noteWorkshop: string | null;
    createdAt: Date;
    customer: Customer | null;
    items: OrderItem[];
}
