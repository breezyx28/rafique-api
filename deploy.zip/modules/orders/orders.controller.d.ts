import { OrdersService } from './orders.service';
import { CreateCustomOrderDto } from './dto/create-custom-order.dto';
import { CreateReadyOrderDto } from './dto/create-ready-order.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { OrderType, OrderStatus } from './entities/order.entity';
export declare class OrdersController {
    private readonly ordersService;
    constructor(ordersService: OrdersService);
    createCustom(dto: CreateCustomOrderDto): Promise<import("./entities/order.entity").Order>;
    createReady(dto: CreateReadyOrderDto): Promise<import("./entities/order.entity").Order>;
    findAll(pagination: PaginationDto, type?: OrderType, status?: OrderStatus, from?: string, to?: string): Promise<{
        data: import("./entities/order.entity").Order[];
        meta: {
            page: number;
            limit: number;
            total: number;
        };
    }>;
    findOne(id: string): Promise<import("./entities/order.entity").Order>;
    update(id: string, body: {
        status?: OrderStatus;
        paid?: number;
    }): Promise<import("./entities/order.entity").Order>;
    remove(id: string): Promise<{
        ok: boolean;
    }>;
}
