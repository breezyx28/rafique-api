import { Repository } from 'typeorm';
import { Order, OrderType, OrderStatus } from './entities/order.entity';
import { OrderItem } from './entities/order-item.entity';
import { OrderMeasurement } from './entities/order-measurement.entity';
import { InventoryItem } from '../inventory/entities/inventory-item.entity';
import { CreateCustomOrderDto } from './dto/create-custom-order.dto';
import { CreateReadyOrderDto } from './dto/create-ready-order.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { NotificationsService } from '../notifications/notifications.service';
export declare class OrdersService {
    private orderRepo;
    private itemRepo;
    private measurementRepo;
    private inventoryRepo;
    private notificationsService;
    constructor(orderRepo: Repository<Order>, itemRepo: Repository<OrderItem>, measurementRepo: Repository<OrderMeasurement>, inventoryRepo: Repository<InventoryItem>, notificationsService: NotificationsService);
    private nextOrderNumber;
    createCustom(dto: CreateCustomOrderDto): Promise<Order>;
    createReady(dto: CreateReadyOrderDto): Promise<Order>;
    findAll(pagination: PaginationDto, filters?: {
        type?: OrderType;
        status?: OrderStatus;
        from?: string;
        to?: string;
    }): Promise<{
        data: Order[];
        meta: {
            page: number;
            limit: number;
            total: number;
        };
    }>;
    findOne(id: number): Promise<Order>;
    findByCustomerWithMeasurements(customerId: number): Promise<Order[]>;
    update(id: number, updates: Partial<Order>): Promise<Order>;
    remove(id: number): Promise<{
        ok: boolean;
    }>;
}
