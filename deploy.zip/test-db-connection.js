"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const typeorm_1 = require("typeorm");
const typeorm_config_1 = require("./config/typeorm.config");
async function testConnection() {
    const ds = new typeorm_1.DataSource({ ...typeorm_config_1.typeOrmConfig, synchronize: false, logging: false });
    try {
        await ds.initialize();
        await ds.query('SELECT 1');
        console.log('Database connection successful.');
    }
    catch (error) {
        console.error('Database connection failed:', error);
        process.exitCode = 1;
    }
    finally {
        if (ds.isInitialized) {
            await ds.destroy();
        }
    }
}
testConnection();
//# sourceMappingURL=test-db-connection.js.map