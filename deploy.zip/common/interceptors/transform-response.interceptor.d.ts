import { NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { Observable } from 'rxjs';
export interface ApiEnvelope<T> {
    data: T;
    message: string;
    code: number;
}
export declare class TransformResponseInterceptor<T> implements NestInterceptor<T, ApiEnvelope<T>> {
    intercept(context: ExecutionContext, next: CallHandler): Observable<ApiEnvelope<T>>;
}
